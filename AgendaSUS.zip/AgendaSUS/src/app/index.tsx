import Login from "../pages/login/login";
export default function HomePage() {
  return (
    <Login />
  );
}