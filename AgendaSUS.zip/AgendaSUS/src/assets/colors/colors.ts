import { StyleSheet } from "react-native";

export const COLORS = {
    //Principais cores do app
    placeholder_text: '#b4b4b4',
    azul_principal: '#368dc4',
    branco: '#FFFFFF',
    preto: '#000000',
    // Adicione outras cores aqui
};